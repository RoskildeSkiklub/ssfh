#ifndef PERTELIANLIB2_H
#define PERTELIANLIB2_H

#ifdef WIN32
#ifdef PERTELIANLIB2_EXPORTS
#define PERTELIANLIB2_DLL __declspec(dllexport)
#else
#ifdef PERTELIANLIB2_STATIC
#define PERTELIANLIB2_DLL
#else
#define PERTELIANLIB2_DLL __declspec(dllimport)
#endif
#endif
#else
#define PERTELIANLIB2_DLL
#endif

#ifndef __cplusplus
# define EXTERN extern
#else
# define EXTERN extern "C"
#endif

#if _MSC_VER > 1000
#pragma once
#endif

/**
 * Automatically detects and initializes a Pertelian LCD device.
 *
 * There is a small 3s delay for initialization
 *
 * \return The device ID of the opened Pertelian LCD device or 0 if device is not found
 */
EXTERN PERTELIANLIB2_DLL unsigned int Pertelian_Open();

/**
 * Closes a Pertelian LCD device and releases resources.
 *
 * \param DeviceId Device ID of an opened Pertelian LCD device returned by Pertelian_Open()
 *  \sa Pertelian_Open()
 */
EXTERN PERTELIANLIB2_DLL void Pertelian_Close(unsigned int DeviceId);

/**
 * Query the open state of a Pertelian LCD device.
 *
 * \return 1 if device is open, 0 if device is closed
 *  \sa Pertelian_Open()
 */
EXTERN PERTELIANLIB2_DLL int Pertelian_IsDeviceOpen(unsigned int DeviceId);

/**
 * Clears the LCD screen.
 *
 * \param DeviceId Device ID of an opened Pertelian LCD device returned by Pertelian_Open()
 *  \sa Pertelian_Open()
 */
EXTERN PERTELIANLIB2_DLL void Pertelian_Clear(unsigned int DeviceId);

/**
 * Writes a string to the LCD screen.
 *
 * \param DeviceId Device ID of an opened Pertelian LCD device returned by Pertelian_Open()
 * \param StringData Contents of the string
 * \param Row Starting row on the LCD screen.  From 1 to 4.
 * \param Column Starting column on the LCD screen.  From 1 to 20.
 *  \sa Pertelian_Open()
 */
EXTERN PERTELIANLIB2_DLL void Pertelian_WriteString(unsigned int DeviceId, const char* StringData, unsigned int Row, unsigned int Column);

/**
 * Load a custom character pattern into a memory slot.  Once a pattern is loaded, it is kept in memory until it is overwritten or unit is powered off.
 *
 * \param DeviceId Device ID of an opened Pertelian LCD device returned by Pertelian_Open()
 * \param MemoryLocation Memory locatation to store the character.  From 1 to 8.
 * \param CharacterData[] Pattern of the character.  Patterns are arranged as 8, 5-bit lines.  Each line is a character value. The value of a character is a 5 bit value MSB (Most Significant Bit) first -- i.e. 0 for no bit pattern, 31 for all bit pattern
 *  \sa Pertelian_Open()
 */
EXTERN PERTELIANLIB2_DLL void Pertelian_LoadCustomCharacterIntoMemory(unsigned int DeviceId, unsigned int MemoryLocation, unsigned char CharacterData[]);

/**
 * Writes a custom character from a memory slot
 *
 * \param DeviceId Device ID of an opened Pertelian LCD device returned by Pertelian_Open()
 * \param MemoryLocation Memory location of a pattern loaded with Pertelian_LoadCustomCharacterIntoMemory(). From 1 to 8.
 * \param Row Starting row on the LCD screen.  From 1 to 4.
 * \param Column Starting column on the LCD screen.  From 1 to 20.
 *  \sa Pertelian_Open(), Pertelian_LoadCustomCharacterIntoMemory()
 */
EXTERN PERTELIANLIB2_DLL void Pertelian_WriteCustomCharacter(unsigned int DeviceId, unsigned int MemoryLocation, unsigned int Row, unsigned int Column);

/**
 * Set the LCD backlight
 *
 * \param DeviceId Device ID of an opened Pertelian LCD device returned by Pertelian_Open()
 * \param BacklightOn 1 to set backlight on, 0 to set backlight off
 *  \sa Pertelian_Open()
 */
EXTERN PERTELIANLIB2_DLL void Pertelian_SetBacklight(unsigned int DeviceId, unsigned int BacklightOn);

/**
 * Query the state of the LCD backlight
 *
 * \param DeviceId Device ID of an opened Pertelian LCD device returned by Pertelian_Open()
 *  \sa Pertelian_Open()
 */
EXTERN PERTELIANLIB2_DLL int Pertelian_IsBacklightOn(unsigned int DeviceId);

#ifdef WIN32
/**
 * Device events. (Windows only)
 *
 * DeviceAdded - This event occurs when a Pertelian LCD device is plugged into the USB port
 *
 * DeviceRemoved - This event occurs when a Pertelian LCD device is removed from the USB port
 */
enum DeviceEventType{DeviceAdded, DeviceRemoved };

/**
 * Register a callback function for device events. (Windows only)
 *
 * \param deviceEvent A callback function that has the signature void deviceEventHandler(void* pArg, DeviceEventType eventTypetype, int deviceId)
 *  DeviceRemoved: used to identify which device was removed.  deviceId is closed and invalid upon removal\n
 *  DeviceAdded: used to identify which device has been added.  deviceId is a valid identifier after this event\n
 * \param pArg The first argument to pass in to the callback function.  \n\n
 * \see DeviceEventType
 */
EXTERN PERTELIANLIB2_DLL void Pertelian_RegisterForDeviceEvents(void (*deviceEvent)(void* pArg, DeviceEventType eventType, int deviceId), void* pArg);
#endif

#endif
