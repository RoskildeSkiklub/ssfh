using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using com.pertelian;

namespace Hangman
{
    class Hangman
    {
        static void Main(string[] args)
        {
	        int deviceId = 0;
	        ArrayList wordDictionary = new ArrayList();
	        bool gameRunning = true;
	        char letter;
            int TRIES = 10;

	        wordDictionary.Add("antique");
	        wordDictionary.Add("weekend");
	        wordDictionary.Add("origin");
	        wordDictionary.Add("limerick");
	        wordDictionary.Add("hometown");
	        wordDictionary.Add("familiar");
	        wordDictionary.Add("agrestic");
	        wordDictionary.Add("latchet");
	        wordDictionary.Add("freedom");
	        wordDictionary.Add("bluegrass");

            deviceId = PertelianLib2.Instance.Pertelian_Open();

            if (deviceId > 0)
            {
                while(gameRunning)
		        {
			        PertelianLib2.Instance.Pertelian_Clear(deviceId);
			        string word = wordDictionary[new Random().Next(wordDictionary.Count)] as string;

			        string wordPuzzle = "";
			        for(int i=0;i<word.Length;i++)
				        wordPuzzle+="_";

			        int totalTries = TRIES;
			        int triesLeft = TRIES;

			        while(!WordSolved(wordPuzzle) && triesLeft > 0)
			        {
                        PertelianLib2.Instance.Pertelian_WriteString(deviceId, wordPuzzle, 1, 1);
				        String status = "Try #"+(totalTries - triesLeft + 1)+ " / "+totalTries;
                        PertelianLib2.Instance.Pertelian_WriteString(deviceId, "                    ", 2, 1);
                        PertelianLib2.Instance.Pertelian_WriteString(deviceId, status, 2, 1);

                        letter = Console.ReadKey().KeyChar; 

				        int location = 0;
                        location = word.IndexOf(letter, location);
                        while (location>=0)
				        {
                            wordPuzzle = wordPuzzle.Remove(location,1);
                            wordPuzzle = wordPuzzle.Insert(location, "" + letter);
					        location++;
                            location = word.IndexOf(letter, location);
				        }

				        triesLeft--;
			        }

			        if(WordSolved(wordPuzzle))
			        {
                        PertelianLib2.Instance.Pertelian_WriteString(deviceId, "                    ", 2, 1);
                        PertelianLib2.Instance.Pertelian_WriteString(deviceId, "You won!", 2, 1);
			        }

                    PertelianLib2.Instance.Pertelian_WriteString(deviceId, "Play again? (y/n)", 3, 1);
                    letter = Console.ReadKey().KeyChar; 
			        while(letter!='y'&&letter!='n')
                        letter = Console.ReadKey().KeyChar; 

			        if(letter == 'n')
				        gameRunning = false;
		        }

                PertelianLib2.Instance.Pertelian_Close(deviceId);
	        }
	        else
	        {
		        Console.WriteLine("Could not open LCD device");
	        }
        }

        static bool WordSolved(string word)
        {
	        if(word.IndexOf("_") >=0 )
		        return false;
	        return true;
        }
    }
}
