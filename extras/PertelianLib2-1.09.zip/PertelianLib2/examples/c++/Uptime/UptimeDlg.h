// UptimeDlg.h : header file
//

#pragma once
#include "afxwin.h"


// CUptimeDlg dialog
class CUptimeDlg : public CDialog
{
// Construction
public:
	CUptimeDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_UPTIME_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

private:
	unsigned int m_deviceId;

	static BOOL GetUpTime(DWORD& seconds);

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CStatic m_lcdStatusText;
public:
	afx_msg void OnTimer(UINT_PTR nIDEvent);
public:
	afx_msg void OnDestroy();
public:
	CStatic m_systemUptimeText;
};
