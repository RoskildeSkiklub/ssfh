#include "stdafx.h"
#include "Uptime.h"
#include "UptimeDlg.h"
#include <Pdh.h>
#include "PertelianLib2.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CUptimeDlg::CUptimeDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CUptimeDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_deviceId = 0;
}

void CUptimeDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LCD_STATUS, m_lcdStatusText);
	DDX_Control(pDX, IDC_SYSTEM_UPTIME, m_systemUptimeText);
}

BEGIN_MESSAGE_MAP(CUptimeDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_WM_TIMER()
	ON_WM_DESTROY()
END_MESSAGE_MAP()


// CUptimeDlg message handlers

BOOL CUptimeDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	m_deviceId = Pertelian_Open();

	if(m_deviceId > 0)
	{
		m_lcdStatusText.SetWindowText("On");
		Pertelian_SetBacklight(m_deviceId,true);
		Pertelian_Clear(m_deviceId);
		SetTimer(101,1000,NULL);
	}
	else
		m_lcdStatusText.SetWindowText("Off");

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CUptimeDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CUptimeDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CUptimeDlg::OnTimer(UINT_PTR nIDEvent)
{
	if(nIDEvent == 101)
	{
		DWORD totalseconds = 0, dwSecs = 0, dwMins = 0, dwHours, dwDays;
		if(GetUpTime(totalseconds))
		{
			dwDays = (totalseconds / 3600) / 24;
			dwHours = (totalseconds / 3600) % 24;
			dwMins = (totalseconds % 3600) / 60;
			dwSecs = totalseconds % 60;
			
			CString timeUp;
			timeUp.Format("%02dD %02dH %02dM %02dS", dwDays, dwHours, dwMins, dwSecs);

			Pertelian_WriteString(m_deviceId,"System Uptime",1,1);
			Pertelian_WriteString(m_deviceId,timeUp,2,1);

			m_systemUptimeText.SetWindowTextA(timeUp);
		}
	}

	CDialog::OnTimer(nIDEvent);
}


#pragma comment(lib,"pdh.lib")
BOOL CUptimeDlg::GetUpTime(DWORD &seconds)
{
	PDH_STATUS  status;
	HQUERY		perfQuery = NULL;
	HCOUNTER	uptimeCounter;
	char		uptimeCounterPath[] = "\\\\.\\System\\System Up Time";
	PDH_FMT_COUNTERVALUE uptimeValue;

	seconds = 0;
	// Check for NT
	//
	OSVERSIONINFO osvi;    
	ZeroMemory(&osvi, sizeof(OSVERSIONINFO));
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFO);
	if(!GetVersionEx(&osvi) || (osvi.dwPlatformId != VER_PLATFORM_WIN32_NT))
		return FALSE;//unknown OS or not NT based

	if( PdhOpenQuery( NULL, 0, &perfQuery ) != ERROR_SUCCESS )
		return FALSE;

	//
	// Associate the uptime counter with the query
	//
	status = PdhAddCounter(perfQuery, uptimeCounterPath,0, &uptimeCounter);
	if( status != ERROR_SUCCESS )
		return FALSE;
	status = PdhCollectQueryData( perfQuery );
	if( status != ERROR_SUCCESS )
		return FALSE;

	//
	// Get the formatted counter value
	//
	status = PdhGetFormattedCounterValue(uptimeCounter, PDH_FMT_LARGE , NULL, &uptimeValue);
	if( status != ERROR_SUCCESS )
		return FALSE;

	PdhRemoveCounter(uptimeCounter);
	PdhCloseQuery( &perfQuery );

	seconds = (DWORD) (uptimeValue.largeValue);
	return TRUE;
}
void CUptimeDlg::OnDestroy()
{
	CDialog::OnDestroy();
	Pertelian_Close(m_deviceId);
}
