// Hangman

#include "PertelianLib2.h"
#include <stdio.h>
#include <tchar.h>
#include <iostream>
#include <sstream>
#include <vector>
#include <time.h>
#include <conio.h>

using namespace std;

#define TRIES 10

bool WordSolved(string);

int _tmain(int argc, _TCHAR* argv[])
{
	unsigned int deviceId = 0;
	vector<string> wordDictionary;
	bool gameRunning = true;
	char letter;

	srand ((unsigned int)time(NULL));

	wordDictionary.push_back("antique");
	wordDictionary.push_back("weekend");
	wordDictionary.push_back("origin");
	wordDictionary.push_back("limerick");
	wordDictionary.push_back("hometown");
	wordDictionary.push_back("familiar");
	wordDictionary.push_back("agrestic");
	wordDictionary.push_back("latchet");
	wordDictionary.push_back("freedom");
	wordDictionary.push_back("bluegrass");

	deviceId = Pertelian_Open();

	if(deviceId > 0)
	{
		while(gameRunning)
		{
			Pertelian_Clear(deviceId);
			string word = wordDictionary[rand() % wordDictionary.size()];

			string wordPuzzle("");
			for(unsigned int i=0;i<word.size();i++)
				wordPuzzle+="_";

			int totalTries = TRIES;
			int triesLeft = TRIES;

			while(!WordSolved(wordPuzzle) && triesLeft > 0)
			{
				Pertelian_WriteString(deviceId,wordPuzzle.c_str(),1,1);
				ostringstream status;
				status << "Try #" << (totalTries - triesLeft + 1) << " / " << totalTries;
				Pertelian_WriteString(deviceId,"                    ",2,1);
				Pertelian_WriteString(deviceId,status.str().c_str(),2,1);

				letter = _getch();

				string::size_type location = 0;
				while((location = word.find(letter,location))!=string::npos)
				{
					wordPuzzle[location] = letter;
					location++;
				}

				triesLeft--;
			}

			if(WordSolved(wordPuzzle))
			{
				Pertelian_WriteString(deviceId,"                    ",2,1);
				Pertelian_WriteString(deviceId,"You won!",2,1);
			}

			Pertelian_WriteString(deviceId,"Play again? (y/n)",3,1);
			letter = _getch();
			while(letter!='y'&&letter!='n')
				letter = _getch();

			if(letter == 'n')
				gameRunning = false;
		}
		Pertelian_Close(deviceId);
	}
	else
	{
		cout<<"Could not open LCD device"<<endl;
	}
	return 0;
}

bool WordSolved(string word)
{
	if(word.find("_") != string::npos )
		return false;
	return true;
}
