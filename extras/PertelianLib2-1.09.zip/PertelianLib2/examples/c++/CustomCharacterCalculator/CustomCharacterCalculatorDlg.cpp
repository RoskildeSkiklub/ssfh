// CustomCharacterCalculatorDlg.cpp : implementation file
//

#include "stdafx.h"
#include "CustomCharacterCalculator.h"
#include "CustomCharacterCalculatorDlg.h"
#include "PertelianLib2.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CCustomCharacterCalculatorDlg dialog




CCustomCharacterCalculatorDlg::CCustomCharacterCalculatorDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCustomCharacterCalculatorDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_deviceId = 0;
}

void CCustomCharacterCalculatorDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_CHECK1, m_check1);
	DDX_Control(pDX, IDC_CHECK2, m_check2);
	DDX_Control(pDX, IDC_CHECK3, m_check3);
	DDX_Control(pDX, IDC_CHECK4, m_check4);
	DDX_Control(pDX, IDC_CHECK5, m_check5);
	DDX_Control(pDX, IDC_CHECK6, m_check6);
	DDX_Control(pDX, IDC_CHECK7, m_check7);
	DDX_Control(pDX, IDC_CHECK8, m_check8);
	DDX_Control(pDX, IDC_CHECK9, m_check9);
	DDX_Control(pDX, IDC_CHECK10, m_check10);
	DDX_Control(pDX, IDC_CHECK11, m_check11);
	DDX_Control(pDX, IDC_CHECK12, m_check12);
	DDX_Control(pDX, IDC_CHECK13, m_check13);
	DDX_Control(pDX, IDC_CHECK14, m_check14);
	DDX_Control(pDX, IDC_CHECK15, m_check15);
	DDX_Control(pDX, IDC_CHECK16, m_check16);
	DDX_Control(pDX, IDC_CHECK17, m_check17);
	DDX_Control(pDX, IDC_CHECK18, m_check18);
	DDX_Control(pDX, IDC_CHECK19, m_check19);
	DDX_Control(pDX, IDC_CHECK20, m_check20);
	DDX_Control(pDX, IDC_CHECK21, m_check21);
	DDX_Control(pDX, IDC_CHECK22, m_check22);
	DDX_Control(pDX, IDC_CHECK23, m_check23);
	DDX_Control(pDX, IDC_CHECK24, m_check24);
	DDX_Control(pDX, IDC_CHECK25, m_check25);
	DDX_Control(pDX, IDC_CHECK26, m_check26);
	DDX_Control(pDX, IDC_CHECK27, m_check27);
	DDX_Control(pDX, IDC_CHECK28, m_check28);
	DDX_Control(pDX, IDC_CHECK29, m_check29);
	DDX_Control(pDX, IDC_CHECK30, m_check30);
	DDX_Control(pDX, IDC_CHECK31, m_check31);
	DDX_Control(pDX, IDC_CHECK32, m_check32);
	DDX_Control(pDX, IDC_CHECK33, m_check33);
	DDX_Control(pDX, IDC_CHECK34, m_check34);
	DDX_Control(pDX, IDC_CHECK35, m_check35);
	DDX_Control(pDX, IDC_CHECK36, m_check36);
	DDX_Control(pDX, IDC_CHECK37, m_check37);
	DDX_Control(pDX, IDC_CHECK38, m_check38);
	DDX_Control(pDX, IDC_CHECK39, m_check39);
	DDX_Control(pDX, IDC_CHECK40, m_check40);
	DDX_Control(pDX, IDC_VALUES, m_valuesText);
}

BEGIN_MESSAGE_MAP(CCustomCharacterCalculatorDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_CHECK1, &CCustomCharacterCalculatorDlg::OnBnClickedCheck1)
	ON_BN_CLICKED(IDC_CHECK2, &CCustomCharacterCalculatorDlg::OnBnClickedCheck2)
	ON_BN_CLICKED(IDC_CHECK3, &CCustomCharacterCalculatorDlg::OnBnClickedCheck3)
	ON_BN_CLICKED(IDC_CHECK4, &CCustomCharacterCalculatorDlg::OnBnClickedCheck4)
	ON_BN_CLICKED(IDC_CHECK5, &CCustomCharacterCalculatorDlg::OnBnClickedCheck5)
	ON_BN_CLICKED(IDC_CHECK6, &CCustomCharacterCalculatorDlg::OnBnClickedCheck6)
	ON_BN_CLICKED(IDC_CHECK7, &CCustomCharacterCalculatorDlg::OnBnClickedCheck7)
	ON_BN_CLICKED(IDC_CHECK8, &CCustomCharacterCalculatorDlg::OnBnClickedCheck8)
	ON_BN_CLICKED(IDC_CHECK9, &CCustomCharacterCalculatorDlg::OnBnClickedCheck9)
	ON_BN_CLICKED(IDC_CHECK10, &CCustomCharacterCalculatorDlg::OnBnClickedCheck10)
	ON_BN_CLICKED(IDC_CHECK11, &CCustomCharacterCalculatorDlg::OnBnClickedCheck11)
	ON_BN_CLICKED(IDC_CHECK12, &CCustomCharacterCalculatorDlg::OnBnClickedCheck12)
	ON_BN_CLICKED(IDC_CHECK13, &CCustomCharacterCalculatorDlg::OnBnClickedCheck13)
	ON_BN_CLICKED(IDC_CHECK14, &CCustomCharacterCalculatorDlg::OnBnClickedCheck14)
	ON_BN_CLICKED(IDC_CHECK15, &CCustomCharacterCalculatorDlg::OnBnClickedCheck15)
	ON_BN_CLICKED(IDC_CHECK16, &CCustomCharacterCalculatorDlg::OnBnClickedCheck16)
	ON_BN_CLICKED(IDC_CHECK17, &CCustomCharacterCalculatorDlg::OnBnClickedCheck17)
	ON_BN_CLICKED(IDC_CHECK18, &CCustomCharacterCalculatorDlg::OnBnClickedCheck18)
	ON_BN_CLICKED(IDC_CHECK19, &CCustomCharacterCalculatorDlg::OnBnClickedCheck19)
	ON_BN_CLICKED(IDC_CHECK20, &CCustomCharacterCalculatorDlg::OnBnClickedCheck20)
	ON_BN_CLICKED(IDC_CHECK21, &CCustomCharacterCalculatorDlg::OnBnClickedCheck21)
	ON_BN_CLICKED(IDC_CHECK22, &CCustomCharacterCalculatorDlg::OnBnClickedCheck22)
	ON_BN_CLICKED(IDC_CHECK23, &CCustomCharacterCalculatorDlg::OnBnClickedCheck23)
	ON_BN_CLICKED(IDC_CHECK24, &CCustomCharacterCalculatorDlg::OnBnClickedCheck24)
	ON_BN_CLICKED(IDC_CHECK25, &CCustomCharacterCalculatorDlg::OnBnClickedCheck25)
	ON_BN_CLICKED(IDC_CHECK26, &CCustomCharacterCalculatorDlg::OnBnClickedCheck26)
	ON_BN_CLICKED(IDC_CHECK27, &CCustomCharacterCalculatorDlg::OnBnClickedCheck27)
	ON_BN_CLICKED(IDC_CHECK28, &CCustomCharacterCalculatorDlg::OnBnClickedCheck28)
	ON_BN_CLICKED(IDC_CHECK29, &CCustomCharacterCalculatorDlg::OnBnClickedCheck29)
	ON_BN_CLICKED(IDC_CHECK30, &CCustomCharacterCalculatorDlg::OnBnClickedCheck30)
	ON_BN_CLICKED(IDC_CHECK31, &CCustomCharacterCalculatorDlg::OnBnClickedCheck31)
	ON_BN_CLICKED(IDC_CHECK32, &CCustomCharacterCalculatorDlg::OnBnClickedCheck32)
	ON_BN_CLICKED(IDC_CHECK33, &CCustomCharacterCalculatorDlg::OnBnClickedCheck33)
	ON_BN_CLICKED(IDC_CHECK34, &CCustomCharacterCalculatorDlg::OnBnClickedCheck34)
	ON_BN_CLICKED(IDC_CHECK35, &CCustomCharacterCalculatorDlg::OnBnClickedCheck35)
	ON_BN_CLICKED(IDC_CHECK36, &CCustomCharacterCalculatorDlg::OnBnClickedCheck36)
	ON_BN_CLICKED(IDC_CHECK37, &CCustomCharacterCalculatorDlg::OnBnClickedCheck37)
	ON_BN_CLICKED(IDC_CHECK38, &CCustomCharacterCalculatorDlg::OnBnClickedCheck38)
	ON_BN_CLICKED(IDC_CHECK39, &CCustomCharacterCalculatorDlg::OnBnClickedCheck39)
	ON_BN_CLICKED(IDC_CHECK40, &CCustomCharacterCalculatorDlg::OnBnClickedCheck40)
	ON_BN_CLICKED(IDC_COL1, &CCustomCharacterCalculatorDlg::OnBnClickedCol1)
	ON_BN_CLICKED(IDC_COL2, &CCustomCharacterCalculatorDlg::OnBnClickedCol2)
	ON_BN_CLICKED(IDC_COL3, &CCustomCharacterCalculatorDlg::OnBnClickedCol3)
	ON_BN_CLICKED(IDC_COL4, &CCustomCharacterCalculatorDlg::OnBnClickedCol4)
	ON_BN_CLICKED(IDC_COL5, &CCustomCharacterCalculatorDlg::OnBnClickedCol5)
	ON_BN_CLICKED(IDC_ROW1, &CCustomCharacterCalculatorDlg::OnBnClickedRow1)
	ON_BN_CLICKED(IDC_ROW2, &CCustomCharacterCalculatorDlg::OnBnClickedRow2)
	ON_BN_CLICKED(IDC_ROW3, &CCustomCharacterCalculatorDlg::OnBnClickedRow3)
	ON_BN_CLICKED(IDC_ROW4, &CCustomCharacterCalculatorDlg::OnBnClickedRow4)
	ON_BN_CLICKED(IDC_ROW5, &CCustomCharacterCalculatorDlg::OnBnClickedRow5)
	ON_BN_CLICKED(IDC_ROW6, &CCustomCharacterCalculatorDlg::OnBnClickedRow6)
	ON_BN_CLICKED(IDC_ROW7, &CCustomCharacterCalculatorDlg::OnBnClickedRow7)
	ON_BN_CLICKED(IDC_ROW8, &CCustomCharacterCalculatorDlg::OnBnClickedRow8)
	ON_BN_CLICKED(IDC_CLEAR, &CCustomCharacterCalculatorDlg::OnBnClickedClear)
END_MESSAGE_MAP()


// CCustomCharacterCalculatorDlg message handlers

BOOL CCustomCharacterCalculatorDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	m_deviceId = Pertelian_Open();

	if(m_deviceId > 0)
	{
		Pertelian_SetBacklight(m_deviceId,true);
		Pertelian_Clear(m_deviceId);
		drawBox();
	}
	else
		MessageBox("Could not open device","LCD");

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CCustomCharacterCalculatorDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CCustomCharacterCalculatorDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CCustomCharacterCalculatorDlg::OnDestroy()
{
	CDialog::OnDestroy();
	Pertelian_Close(m_deviceId);
}

void CCustomCharacterCalculatorDlg::drawBox()
{
	unsigned char block[] = { 31, 31, 31, 31, 31, 31, 31, 31 };
	unsigned char block2[] = { 31, 31, 31, 31, 0, 0, 0, 0 };

	Pertelian_LoadCustomCharacterIntoMemory(m_deviceId, 1, block);
	Pertelian_LoadCustomCharacterIntoMemory(m_deviceId, 2, block2);

    Pertelian_WriteCustomCharacter(m_deviceId, 1, 1, 1);
    Pertelian_WriteCustomCharacter(m_deviceId, 2, 1, 2);
    Pertelian_WriteCustomCharacter(m_deviceId, 2, 1, 3);
    Pertelian_WriteCustomCharacter(m_deviceId, 2, 1, 4);
	Pertelian_WriteCustomCharacter(m_deviceId, 1, 1, 5);
    Pertelian_WriteCustomCharacter(m_deviceId, 1, 2, 1);
    Pertelian_WriteCustomCharacter(m_deviceId, 1, 2, 5);
    Pertelian_WriteCustomCharacter(m_deviceId, 1, 3, 1);
    Pertelian_WriteCustomCharacter(m_deviceId, 1, 3, 5);
    Pertelian_WriteCustomCharacter(m_deviceId, 1, 4, 1);
    Pertelian_WriteCustomCharacter(m_deviceId, 1, 4, 2);
    Pertelian_WriteCustomCharacter(m_deviceId, 1, 4, 3);
    Pertelian_WriteCustomCharacter(m_deviceId, 1, 4, 4);
	Pertelian_WriteCustomCharacter(m_deviceId, 1, 4, 5);
}

void CCustomCharacterCalculatorDlg::updateCharacter()
{
	unsigned char byte1 = 0;
	unsigned char byte2 = 0;
	unsigned char byte3 = 0;
	unsigned char byte4 = 0;
	unsigned char byte5 = 0;
	unsigned char byte6 = 0;
	unsigned char byte7 = 0;
	unsigned char byte8 = 0;

	byte1 |= 16 * m_check1.GetCheck();
	byte1 |= 8  * m_check2.GetCheck();
	byte1 |= 4  * m_check3.GetCheck();
	byte1 |= 2  * m_check4.GetCheck();
	byte1 |= 1  * m_check5.GetCheck();

	byte2 |= 16 * m_check6.GetCheck();
	byte2 |= 8  * m_check7.GetCheck();
	byte2 |= 4  * m_check8.GetCheck();
	byte2 |= 2  * m_check9.GetCheck();
	byte2 |= 1  * m_check10.GetCheck();

	byte3 |= 16 * m_check11.GetCheck();
	byte3 |= 8  * m_check12.GetCheck();
	byte3 |= 4  * m_check13.GetCheck();
	byte3 |= 2  * m_check14.GetCheck();
	byte3 |= 1  * m_check15.GetCheck();

	byte4 |= 16 * m_check16.GetCheck();
	byte4 |= 8  * m_check17.GetCheck();
	byte4 |= 4  * m_check18.GetCheck();
	byte4 |= 2  * m_check19.GetCheck();
	byte4 |= 1  * m_check20.GetCheck();

	byte5 |= 16 * m_check21.GetCheck();
	byte5 |= 8  * m_check22.GetCheck();
	byte5 |= 4  * m_check23.GetCheck();
	byte5 |= 2  * m_check24.GetCheck();
	byte5 |= 1  * m_check25.GetCheck();

	byte6 |= 16 * m_check26.GetCheck();
	byte6 |= 8  * m_check27.GetCheck();
	byte6 |= 4  * m_check28.GetCheck();
	byte6 |= 2  * m_check29.GetCheck();
	byte6 |= 1  * m_check30.GetCheck();

	byte7 |= 16 * m_check31.GetCheck();
	byte7 |= 8  * m_check32.GetCheck();
	byte7 |= 4  * m_check33.GetCheck();
	byte7 |= 2  * m_check34.GetCheck();
	byte7 |= 1  * m_check35.GetCheck();

	byte8 |= 16 * m_check36.GetCheck();
	byte8 |= 8  * m_check37.GetCheck();
	byte8 |= 4  * m_check38.GetCheck();
	byte8 |= 2  * m_check39.GetCheck();
	byte8 |= 1  * m_check40.GetCheck();

	unsigned char character[] = {byte1, byte2, byte3, byte4, byte5, byte6, byte7, byte8};

	Pertelian_LoadCustomCharacterIntoMemory(m_deviceId, 8, character);
	Pertelian_WriteCustomCharacter(m_deviceId, 8, 2, 3);


	CString values;
	values.Format("{ %d %d %d %d %d %d %d %d }",byte1,byte2,byte3,byte4,byte5,byte6,byte7,byte8);
	m_valuesText.SetWindowTextA(values);
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck1()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck2()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck3()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck4()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck5()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck6()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck7()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck8()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck9()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck10()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck11()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck12()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck13()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck14()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck15()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck16()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck17()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck18()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck19()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck20()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck21()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck22()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck23()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck24()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck25()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck26()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck27()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck28()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck29()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck30()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck31()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck32()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck33()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck34()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck35()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck36()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck37()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck38()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck39()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCheck40()
{
	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCol1()
{
	if(m_check1.GetCheck())
		m_check1.SetCheck(0);
	else
		m_check1.SetCheck(1);

	if(m_check6.GetCheck())
		m_check6.SetCheck(0);
	else
		m_check6.SetCheck(1);

	if(m_check11.GetCheck())
		m_check11.SetCheck(0);
	else
		m_check11.SetCheck(1);

	if(m_check16.GetCheck())
		m_check16.SetCheck(0);
	else
		m_check16.SetCheck(1);

	if(m_check21.GetCheck())
		m_check21.SetCheck(0);
	else
		m_check21.SetCheck(1);

	if(m_check26.GetCheck())
		m_check26.SetCheck(0);
	else
		m_check26.SetCheck(1);

	if(m_check31.GetCheck())
		m_check31.SetCheck(0);
	else
		m_check31.SetCheck(1);

	if(m_check36.GetCheck())
		m_check36.SetCheck(0);
	else
		m_check36.SetCheck(1);

	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCol2()
{
	if(m_check2.GetCheck())
		m_check2.SetCheck(0);
	else
		m_check2.SetCheck(1);

	if(m_check7.GetCheck())
		m_check7.SetCheck(0);
	else
		m_check7.SetCheck(1);

	if(m_check12.GetCheck())
		m_check12.SetCheck(0);
	else
		m_check12.SetCheck(1);

	if(m_check17.GetCheck())
		m_check17.SetCheck(0);
	else
		m_check17.SetCheck(1);

	if(m_check22.GetCheck())
		m_check22.SetCheck(0);
	else
		m_check22.SetCheck(1);

	if(m_check27.GetCheck())
		m_check27.SetCheck(0);
	else
		m_check27.SetCheck(1);

	if(m_check32.GetCheck())
		m_check32.SetCheck(0);
	else
		m_check32.SetCheck(1);

	if(m_check37.GetCheck())
		m_check37.SetCheck(0);
	else
		m_check37.SetCheck(1);

	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCol3()
{
	if(m_check3.GetCheck())
		m_check3.SetCheck(0);
	else
		m_check3.SetCheck(1);

	if(m_check8.GetCheck())
		m_check8.SetCheck(0);
	else
		m_check8.SetCheck(1);

	if(m_check13.GetCheck())
		m_check13.SetCheck(0);
	else
		m_check13.SetCheck(1);

	if(m_check18.GetCheck())
		m_check18.SetCheck(0);
	else
		m_check18.SetCheck(1);

	if(m_check23.GetCheck())
		m_check23.SetCheck(0);
	else
		m_check23.SetCheck(1);

	if(m_check28.GetCheck())
		m_check28.SetCheck(0);
	else
		m_check28.SetCheck(1);

	if(m_check33.GetCheck())
		m_check33.SetCheck(0);
	else
		m_check33.SetCheck(1);

	if(m_check38.GetCheck())
		m_check38.SetCheck(0);
	else
		m_check38.SetCheck(1);

	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCol4()
{
	if(m_check4.GetCheck())
		m_check4.SetCheck(0);
	else
	m_check4.SetCheck(1);

	if(m_check9.GetCheck())
		m_check9.SetCheck(0);
	else
		m_check9.SetCheck(1);

	if(m_check14.GetCheck())
		m_check14.SetCheck(0);
	else
		m_check14.SetCheck(1);

	if(m_check19.GetCheck())
		m_check19.SetCheck(0);
	else
		m_check19.SetCheck(1);

	if(m_check24.GetCheck())
		m_check24.SetCheck(0);
	else
		m_check24.SetCheck(1);

	if(m_check29.GetCheck())
		m_check29.SetCheck(0);
	else
		m_check29.SetCheck(1);

	if(m_check34.GetCheck())
		m_check34.SetCheck(0);
	else
		m_check34.SetCheck(1);

	if(m_check39.GetCheck())
		m_check39.SetCheck(0);
	else
		m_check39.SetCheck(1);

	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedCol5()
{
	if(m_check5.GetCheck())
		m_check5.SetCheck(0);
	else
		m_check5.SetCheck(1);

	if(m_check10.GetCheck())
		m_check10.SetCheck(0);
	else
		m_check10.SetCheck(1);

	if(m_check15.GetCheck())
		m_check15.SetCheck(0);
	else
		m_check15.SetCheck(1);

	if(m_check20.GetCheck())
		m_check20.SetCheck(0);
	else
		m_check20.SetCheck(1);

	if(m_check25.GetCheck())
		m_check25.SetCheck(0);
	else
		m_check25.SetCheck(1);

	if(m_check30.GetCheck())
		m_check30.SetCheck(0);
	else
		m_check30.SetCheck(1);

	if(m_check35.GetCheck())
		m_check35.SetCheck(0);
	else
		m_check35.SetCheck(1);

	if(m_check40.GetCheck())
		m_check40.SetCheck(0);
	else
		m_check40.SetCheck(1);

	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedRow1()
{
	if(m_check1.GetCheck())
		m_check1.SetCheck(0);
	else
		m_check1.SetCheck(1);

	if(m_check2.GetCheck())
		m_check2.SetCheck(0);
	else
		m_check2.SetCheck(1);

	if(m_check3.GetCheck())
		m_check3.SetCheck(0);
	else
		m_check3.SetCheck(1);

	if(m_check4.GetCheck())
		m_check4.SetCheck(0);
	else
		m_check4.SetCheck(1);

	if(m_check5.GetCheck())
		m_check5.SetCheck(0);
	else
		m_check5.SetCheck(1);

	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedRow2()
{
	if(m_check6.GetCheck())
		m_check6.SetCheck(0);
	else
		m_check6.SetCheck(1);

	if(m_check7.GetCheck())
		m_check7.SetCheck(0);
	else
		m_check7.SetCheck(1);

	if(m_check8.GetCheck())
		m_check8.SetCheck(0);
	else
		m_check8.SetCheck(1);

	if(m_check9.GetCheck())
		m_check9.SetCheck(0);
	else
		m_check9.SetCheck(1);

	if(m_check10.GetCheck())
		m_check10.SetCheck(0);
	else
		m_check10.SetCheck(1);

	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedRow3()
{
	if(m_check11.GetCheck())
		m_check11.SetCheck(0);
	else
		m_check11.SetCheck(1);

	if(m_check12.GetCheck())
		m_check12.SetCheck(0);
	else
		m_check12.SetCheck(1);

	if(m_check13.GetCheck())
		m_check13.SetCheck(0);
	else
		m_check13.SetCheck(1);

	if(m_check14.GetCheck())
		m_check14.SetCheck(0);
	else
		m_check14.SetCheck(1);

	if(m_check15.GetCheck())
		m_check15.SetCheck(0);
	else
		m_check15.SetCheck(1);

	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedRow4()
{
	if(m_check16.GetCheck())
		m_check16.SetCheck(0);
	else
		m_check16.SetCheck(1);

	if(m_check17.GetCheck())
		m_check17.SetCheck(0);
	else
		m_check17.SetCheck(1);

	if(m_check18.GetCheck())
		m_check18.SetCheck(0);
	else
		m_check18.SetCheck(1);

	if(m_check19.GetCheck())
		m_check19.SetCheck(0);
	else
		m_check19.SetCheck(1);

	if(m_check20.GetCheck())
		m_check20.SetCheck(0);
	else
		m_check20.SetCheck(1);

	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedRow5()
{
	if(m_check21.GetCheck())
		m_check21.SetCheck(0);
	else
		m_check21.SetCheck(1);

	if(m_check22.GetCheck())
		m_check22.SetCheck(0);
	else
		m_check22.SetCheck(1);

	if(m_check23.GetCheck())
		m_check23.SetCheck(0);
	else
		m_check23.SetCheck(1);

	if(m_check24.GetCheck())
		m_check24.SetCheck(0);
	else
		m_check24.SetCheck(1);

	if(m_check25.GetCheck())
		m_check25.SetCheck(0);
	else
		m_check25.SetCheck(1);

	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedRow6()
{
	if(m_check26.GetCheck())
		m_check26.SetCheck(0);
	else
		m_check26.SetCheck(1);

	if(m_check27.GetCheck())
		m_check27.SetCheck(0);
	else
		m_check27.SetCheck(1);

	if(m_check28.GetCheck())
		m_check28.SetCheck(0);
	else
		m_check28.SetCheck(1);

	if(m_check29.GetCheck())
		m_check29.SetCheck(0);
	else
		m_check29.SetCheck(1);

	if(m_check30.GetCheck())
		m_check30.SetCheck(0);
	else
		m_check30.SetCheck(1);

	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedRow7()
{
	if(m_check31.GetCheck())
		m_check31.SetCheck(0);
	else
		m_check31.SetCheck(1);

	if(m_check32.GetCheck())
		m_check32.SetCheck(0);
	else
		m_check32.SetCheck(1);

	if(m_check33.GetCheck())
		m_check33.SetCheck(0);
	else
		m_check33.SetCheck(1);

	if(m_check34.GetCheck())
		m_check34.SetCheck(0);
	else
		m_check34.SetCheck(1);

	if(m_check35.GetCheck())
		m_check35.SetCheck(0);
	else
		m_check35.SetCheck(1);

	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedRow8()
{
	if(m_check36.GetCheck())
		m_check36.SetCheck(0);
	else
		m_check36.SetCheck(1);

	if(m_check37.GetCheck())
		m_check37.SetCheck(0);
	else
		m_check37.SetCheck(1);

	if(m_check38.GetCheck())
		m_check38.SetCheck(0);
	else
		m_check38.SetCheck(1);

	if(m_check39.GetCheck())
		m_check39.SetCheck(0);
	else
		m_check39.SetCheck(1);

	if(m_check40.GetCheck())
		m_check40.SetCheck(0);
	else
		m_check40.SetCheck(1);

	updateCharacter();
}

void CCustomCharacterCalculatorDlg::OnBnClickedClear()
{
	m_check1.SetCheck(0);
	m_check2.SetCheck(0);
	m_check3.SetCheck(0);
	m_check4.SetCheck(0);
	m_check5.SetCheck(0);
	m_check6.SetCheck(0);
	m_check7.SetCheck(0);
	m_check8.SetCheck(0);
	m_check9.SetCheck(0);
	m_check10.SetCheck(0);
	m_check11.SetCheck(0);
	m_check12.SetCheck(0);
	m_check13.SetCheck(0);
	m_check14.SetCheck(0);
	m_check15.SetCheck(0);
	m_check16.SetCheck(0);
	m_check17.SetCheck(0);
	m_check18.SetCheck(0);
	m_check19.SetCheck(0);
	m_check20.SetCheck(0);
	m_check21.SetCheck(0);
	m_check22.SetCheck(0);
	m_check23.SetCheck(0);
	m_check24.SetCheck(0);
	m_check25.SetCheck(0);
	m_check26.SetCheck(0);
	m_check27.SetCheck(0);
	m_check28.SetCheck(0);
	m_check29.SetCheck(0);
	m_check30.SetCheck(0);
	m_check31.SetCheck(0);
	m_check32.SetCheck(0);
	m_check33.SetCheck(0);
	m_check34.SetCheck(0);
	m_check35.SetCheck(0);
	m_check36.SetCheck(0);
	m_check37.SetCheck(0);
	m_check38.SetCheck(0);
	m_check39.SetCheck(0);
	m_check40.SetCheck(0);
	updateCharacter();
}
