// CustomCharacterCalculatorDlg.h : header file
//

#pragma once
#include "afxwin.h"


// CCustomCharacterCalculatorDlg dialog
class CCustomCharacterCalculatorDlg : public CDialog
{
// Construction
public:
	CCustomCharacterCalculatorDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_CUSTOMCHARACTERCALCULATOR_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

private:
	unsigned int m_deviceId;
	void drawBox();
	void updateCharacter();

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	CButton m_check1;
public:
	CButton m_check2;
public:
	CButton m_check3;
public:
	CButton m_check4;
public:
	CButton m_check5;
public:
	CButton m_check6;
public:
	CButton m_check7;
public:
	CButton m_check10;
public:
	CButton m_check9;
public:
	CButton m_check8;
public:
	CButton m_check11;
public:
	CButton m_check12;
public:
	CButton m_check13;
public:
	CButton m_check14;
public:
	CButton m_check15;
public:
	CButton m_check16;
public:
	CButton m_check17;
public:
	CButton m_check18;
public:
	CButton m_check19;
public:
	CButton m_check20;
public:
	CButton m_check21;
public:
	CButton m_check22;
public:
	CButton m_check23;
public:
	CButton m_check24;
public:
	CButton m_check25;
public:
	CButton m_check26;
public:
	CButton m_check27;
public:
	CButton m_check28;
public:
	CButton m_check29;
public:
	CButton m_check30;
public:
	CButton m_check31;
public:
	CButton m_check32;
public:
	CButton m_check33;
public:
	CButton m_check34;
public:
	CButton m_check35;
public:
	CButton m_check36;
public:
	CButton m_check37;
public:
	CButton m_check38;
public:
	CButton m_check39;
public:
	CButton m_check40;
public:
	afx_msg void OnDestroy();
public:
	afx_msg void OnBnClickedCheck1();
public:
	afx_msg void OnBnClickedCheck2();
public:
	afx_msg void OnBnClickedCheck3();
public:
	afx_msg void OnBnClickedCheck4();
public:
	afx_msg void OnBnClickedCheck5();
public:
	afx_msg void OnBnClickedCheck6();
public:
	afx_msg void OnBnClickedCheck7();
public:
	afx_msg void OnBnClickedCheck8();
public:
	afx_msg void OnBnClickedCheck9();
public:
	afx_msg void OnBnClickedCheck10();
public:
	afx_msg void OnBnClickedCheck11();
public:
	afx_msg void OnBnClickedCheck12();
public:
	afx_msg void OnBnClickedCheck13();
public:
	afx_msg void OnBnClickedCheck14();
public:
	afx_msg void OnBnClickedCheck15();
public:
	afx_msg void OnBnClickedCheck16();
public:
	afx_msg void OnBnClickedCheck17();
public:
	afx_msg void OnBnClickedCheck18();
public:
	afx_msg void OnBnClickedCheck19();
public:
	afx_msg void OnBnClickedCheck20();
public:
	afx_msg void OnBnClickedCheck21();
public:
	afx_msg void OnBnClickedCheck22();
public:
	afx_msg void OnBnClickedCheck23();
public:
	afx_msg void OnBnClickedCheck24();
public:
	afx_msg void OnBnClickedCheck25();
public:
	afx_msg void OnBnClickedCheck26();
public:
	afx_msg void OnBnClickedCheck27();
public:
	afx_msg void OnBnClickedCheck28();
public:
	afx_msg void OnBnClickedCheck29();
public:
	afx_msg void OnBnClickedCheck30();
public:
	afx_msg void OnBnClickedCheck31();
public:
	afx_msg void OnBnClickedCheck32();
public:
	afx_msg void OnBnClickedCheck33();
public:
	afx_msg void OnBnClickedCheck34();
public:
	afx_msg void OnBnClickedCheck35();
public:
	afx_msg void OnBnClickedCheck36();
public:
	afx_msg void OnBnClickedCheck37();
public:
	afx_msg void OnBnClickedCheck38();
public:
	afx_msg void OnBnClickedCheck39();
public:
	afx_msg void OnBnClickedCheck40();
public:
	CStatic m_valuesText;
public:
	afx_msg void OnBnClickedCol1();
public:
	afx_msg void OnBnClickedCol2();
public:
	afx_msg void OnBnClickedCol3();
public:
	afx_msg void OnBnClickedCol4();
public:
	afx_msg void OnBnClickedCol5();
public:
	afx_msg void OnBnClickedRow1();
public:
	afx_msg void OnBnClickedRow2();
public:
	afx_msg void OnBnClickedRow3();
public:
	afx_msg void OnBnClickedRow4();
public:
	afx_msg void OnBnClickedRow5();
public:
	afx_msg void OnBnClickedRow6();
public:
	afx_msg void OnBnClickedRow7();
public:
	afx_msg void OnBnClickedRow8();
public:
	afx_msg void OnBnClickedClear();
};
