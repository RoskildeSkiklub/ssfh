//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CustomCharacterCalculator.rc
//
#define IDD_CUSTOMCHARACTERCALCULATOR_DIALOG 102
#define IDR_MAINFRAME                   128
#define IDC_CHECK1                      1000
#define IDC_CHECK2                      1001
#define IDC_CHECK3                      1002
#define IDC_CHECK4                      1003
#define IDC_CHECK5                      1004
#define IDC_CHECK6                      1005
#define IDC_CHECK7                      1006
#define IDC_CHECK8                      1007
#define IDC_CHECK9                      1008
#define IDC_CHECK10                     1009
#define IDC_CHECK11                     1010
#define IDC_CHECK12                     1011
#define IDC_CHECK14                     1012
#define IDC_CHECK13                     1013
#define IDC_CHECK15                     1014
#define IDC_CHECK16                     1015
#define IDC_CHECK17                     1016
#define IDC_CHECK19                     1017
#define IDC_CHECK18                     1018
#define IDC_CHECK20                     1019
#define IDC_CHECK21                     1020
#define IDC_CHECK22                     1021
#define IDC_CHECK24                     1022
#define IDC_CHECK23                     1023
#define IDC_CHECK25                     1024
#define IDC_CHECK26                     1025
#define IDC_CHECK27                     1026
#define IDC_CHECK29                     1027
#define IDC_CHECK28                     1028
#define IDC_CHECK30                     1029
#define IDC_CHECK31                     1030
#define IDC_CHECK32                     1031
#define IDC_CHECK34                     1032
#define IDC_CHECK33                     1033
#define IDC_CHECK35                     1034
#define IDC_CHECK36                     1035
#define IDC_CHECK37                     1036
#define IDC_CHECK381                    1037
#define IDC_CHECK39                     1037
#define IDC_CHECK38                     1038
#define IDC_CHECK40                     1039
#define IDC_COL1                        1046
#define IDC_COL2                        1047
#define IDC_COL3                        1048
#define IDC_COL4                        1049
#define IDC_COL5                        1050
#define IDC_ROW1                        1051
#define IDC_ROW2                        1052
#define IDC_ROW3                        1053
#define IDC_ROW4                        1054
#define IDC_ROW5                        1055
#define IDC_ROW6                        1056
#define IDC_ROW7                        1057
#define IDC_ROW8                        1058
#define IDC_VALUES                      1059
#define IDC_BUTTON2                     1060
#define IDC_CLEAR                       1060

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1061
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
