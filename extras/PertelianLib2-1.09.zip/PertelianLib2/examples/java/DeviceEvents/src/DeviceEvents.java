
import com.pertelian.PertelianLib2;

public class DeviceEvents
{
	static class EventListener
	{
		private void deviceEventHandler(int deviceEventType, int deviceId)
		{
			switch(deviceEventType)
			{
				case PertelianLib2.DeviceRemoved:
					System.out.println("Java Device Removed " + deviceId);
					break;
				case PertelianLib2.DeviceAdded:
					System.out.println("Java Device Added " + deviceId);
					PertelianLib2.getInstance().Pertelian_WriteString(deviceId, "I am device "+deviceId, 1, 1);
					break;
			}
		}
	}

    public static void main(String[] args)
    {
		try
		{
			EventListener el = new EventListener();
			PertelianLib2.getInstance().Pertelian_RegisterForDeviceEvents(el);

			int deviceId = PertelianLib2.getInstance().Pertelian_Open();

			if (deviceId > 0)
	        {
				System.out.println("Device "+deviceId+" opened");
				System.out.println("Unplug/plug in device to receive events");
				while(true)
				{
					Thread.sleep(100);
				}
			}
			else
			{
				System.out.println("Could not open device");
			}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
    }

}
