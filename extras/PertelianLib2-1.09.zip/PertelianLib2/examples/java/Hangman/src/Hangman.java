import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Random;

import com.pertelian.PertelianLib2;

public class Hangman
{
    public static void main(String[] args)
    {
    	try
    	{
	        int deviceId = 0;
                ArrayList wordDictionary = new ArrayList();
	        boolean gameRunning = true;
	        char letter;
	        int TRIES = 10;
	
	        wordDictionary.add("antique");
	        wordDictionary.add("weekend");
	        wordDictionary.add("origin");
	        wordDictionary.add("limerick");
	        wordDictionary.add("hometown");
	        wordDictionary.add("familiar");
	        wordDictionary.add("agrestic");
	        wordDictionary.add("latchet");
	        wordDictionary.add("freedom");
	        wordDictionary.add("bluegrass");
	
	        deviceId = PertelianLib2.getInstance().Pertelian_Open();
	
	        if (deviceId > 0)
	        {		
	            while(gameRunning)
		        {
			        PertelianLib2.getInstance().Pertelian_Clear(deviceId);
                                String word = (String)wordDictionary.get(new Random().nextInt(wordDictionary.size()));
	
			        String wordPuzzle = "";
			        for(int i=0;i<word.length();i++)
				        wordPuzzle+="_";
	
			        int totalTries = TRIES;
			        int triesLeft = TRIES;
	
			        while(!WordSolved(wordPuzzle) && triesLeft > 0)
			        {
	                    PertelianLib2.getInstance().Pertelian_WriteString(deviceId, wordPuzzle, 1, 1);
				        String status = "Try #"+(totalTries - triesLeft + 1)+ " / "+totalTries;
	                    PertelianLib2.getInstance().Pertelian_WriteString(deviceId, "                    ", 2, 1);
	                    PertelianLib2.getInstance().Pertelian_WriteString(deviceId, status, 2, 1);
	
	                    String temp = new BufferedReader(new InputStreamReader(System.in)).readLine();

	                    if(temp.length()>0)
	                    {
	                    	letter = temp.charAt(0);
	                    
					        int location = 0;
		                    location = word.indexOf(letter, location);
		                    while (location>=0)
					        {
		                        wordPuzzle = replaceCharAt(wordPuzzle,location,letter);
						        location++;
		                        location = word.indexOf(letter, location);
					        }
		
					        triesLeft--;
	                    }
			        }
	
			        if(WordSolved(wordPuzzle))
			        {
	                    PertelianLib2.getInstance().Pertelian_WriteString(deviceId, "                    ", 2, 1);
	                    PertelianLib2.getInstance().Pertelian_WriteString(deviceId, "You won!", 2, 1);
			        }
	
	                PertelianLib2.getInstance().Pertelian_WriteString(deviceId, "Play again? (y/n)", 3, 1);
	                letter = (char)System.in.read();
			        while(letter!='y'&&letter!='n')
	                    letter = (char)System.in.read();
	
			        if(letter == 'n')
				        gameRunning = false;
		        }
	            
	            PertelianLib2.getInstance().Pertelian_Close(deviceId);
	        }
	        else
	        {
		        System.out.println("Could not open LCD device");
	        }
    	}
        catch(IOException e)
        {
        	System.out.println(e.getMessage());
        }
    }

    public static String replaceCharAt(String s, int pos, char c) {
    	   return s.substring(0,pos) + c + s.substring(pos+1);
    	}
    
    static boolean WordSolved(String word)
    {
        if(word.indexOf("_") >=0 )
	        return false;
        return true;
    }
}
